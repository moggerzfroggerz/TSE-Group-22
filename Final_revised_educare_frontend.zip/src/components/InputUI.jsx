import React, { useState } from 'react';

const PATIENT_EXAMPLES = [
  { label: 'Symptoms', text: 'What are the symptoms of asthma?' },
  { label: 'Diabetes', text: 'What are the symptoms of diabetes?' },
  { label: 'Depression', text: 'What are the signs of depression?' },
  { label: 'Headache', text: 'When should I worry about a headache?' },
];

const CLINICIAN_EXAMPLES = [
  { label: 'Hypertension', text: 'How is hypertension diagnosed?' },
  { label: 'Type 2 diabetes', text: 'What is the first-line drug for type 2 diabetes?' },
  { label: 'Sepsis', text: 'What are the high-risk criteria for suspected sepsis?' },
  { label: 'TIA', text: 'What should happen after a suspected TIA?' },
];

export default function InputUI({ onSubmit, isLoading, userRole }) {
  const [query, setQuery] = useState('');
  const examples = userRole === 'doctor' ? CLINICIAN_EXAMPLES : PATIENT_EXAMPLES;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!isLoading && query.trim()) {
      onSubmit(query.trim(), userRole);
    }
  };

  return (
    <form className="input-form" onSubmit={handleSubmit}>
      <div className="form-group">
        <label htmlFor="query-input">
          {userRole === 'doctor' ? 'Clinical Query' : 'Ask a Question'}
        </label>
        <textarea
          id="query-input"
          className="form-control"
          rows="5"
          placeholder={
            userRole === 'doctor'
              ? 'Enter a clinical question (e.g., NICE-style diagnosis or management query)…'
              : 'Ask about your health (e.g., symptoms, self-care, when to see a GP)…'
          }
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          required
          disabled={isLoading}
        />
      </div>

      <div className="example-chips">
        <small>Quick Queries:</small>
        <div className="chip-container">
          {examples.map((ex) => (
            <button
              key={ex.label}
              type="button"
              className="chip"
              onClick={() => setQuery(ex.text)}
              disabled={isLoading}
              title={ex.text}
            >
              {ex.label}
            </button>
          ))}
        </div>
      </div>

      <button
        type="submit"
        className={`submit-btn ${userRole}-btn`}
        disabled={isLoading || !query.trim()}
      >
        {isLoading ? (
          <>
            <div className="spinner" aria-hidden="true"></div>
            <span>Analyzing…</span>
          </>
        ) : userRole === 'doctor' ? (
          'Run Clinical Analysis'
        ) : (
          'Get Health Info'
        )}
      </button>
    </form>
  );
}
