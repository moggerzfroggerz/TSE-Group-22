import React from 'react';
import SafetyBanner from './SafetyBanner';
import Disclaimer from './Disclaimer';

export default function DisplayOutput({ result }) {
  if (!result) return null;

  const {
    answer_text,
    citations,
    emergency_flag,
    emergency_category,
    refusal,
    mode,
  } = result;

  return (
    <section className="output-section">
      {emergency_flag && <SafetyBanner urgent category={emergency_category} />}

      {!emergency_flag && <SafetyBanner />}

      <div className="response-content">
        <h3>
          {refusal
            ? 'Safety Notice'
            : mode === 'professional'
            ? 'Clinical Response'
            : 'Response'}
        </h3>
        <p style={{ whiteSpace: 'pre-wrap' }}>{answer_text}</p>
      </div>

      {citations && citations.length > 0 && (
        <div className="citations-box">
          <h4>Sources & Citations</h4>
          <ul>
            {citations.map((cite, index) => (
              <li key={`${cite.source}-${cite.title}-${index}`}>
                {cite.url && cite.url !== '#' ? (
                  <a href={cite.url} target="_blank" rel="noopener noreferrer">
                    {cite.title}
                  </a>
                ) : (
                  <span>{cite.title}</span>
                )}
                <span className="citation-source"> — {cite.source}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <Disclaimer />
    </section>
  );
}
