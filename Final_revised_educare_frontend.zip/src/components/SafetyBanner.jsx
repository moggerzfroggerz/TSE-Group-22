import React from 'react';

const CATEGORY_LABELS = {
  cardiac: 'Possible cardiac emergency',
  respiratory: 'Possible respiratory emergency',
  neurological: 'Possible neurological emergency (e.g. stroke)',
  anaphylaxis: 'Possible anaphylaxis',
  paediatric: 'Paediatric emergency',
  self_harm: 'Urgent mental-health support',
};

export default function SafetyBanner({ urgent = false, category = null }) {
  if (urgent) {
    const label = CATEGORY_LABELS[category] || 'Possible medical emergency';
    return (
      <div className="safety-banner urgent" role="alert">
        <strong>⚠️ {label}.</strong>{' '}
        If this may be a medical emergency, seek urgent medical help
        immediately or call emergency services (999 in the UK, 911 in the US).
      </div>
    );
  }

  return (
    <div className="safety-banner">
      <strong>⚠️ Safety Notice:</strong>{' '}
      The information provided by EduCare AI is for educational purposes only
      and should not replace professional medical advice, diagnosis, or
      treatment.
    </div>
  );
}
