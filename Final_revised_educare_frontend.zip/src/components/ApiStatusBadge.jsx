import React from 'react';

export default function ApiStatusBadge({ status }) {
  const { state, detail } = status || {};

  const labels = {
    unknown: 'Initialising…',
    checking: 'Checking API…',
    connected: 'API connected',
    disconnected: 'API offline',
  };

  const className = `api-status-badge ${state}`;
  return (
    <div className={className} title={detail || labels[state]}>
      <span className="api-status-dot" />
      <span className="api-status-label">{labels[state] || 'Unknown'}</span>
      {state === 'connected' && detail && (
        <span className="api-status-detail">· {detail}</span>
      )}
    </div>
  );
}
