// EduCare AI front-end → FastAPI client.
//
// The FastAPI service from `EduCare_MVP_Revised.ipynb` exposes:
//
//   POST /answer
//     request:  { query: string, mode: "patient"|"professional", top_k: int }
//     response: { query, mode, answer_text, citations: [{title, source, url}],
//                 emergency_flag, emergency_category, safety_note, refusal }
//
//   POST /retrieve   { query, mode, top_k }   → list of retrieved chunks
//   GET  /health                              → service status
//
// Configure the API base URL via VITE_API_BASE_URL in `.env`. When unset,
// the client falls back to http://localhost:8000.

const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

// The login screen offers 'doctor' and 'patient' roles; the API expects
// 'professional' and 'patient'. This is the only place that translation
// lives, so keeping the UI copy ('Clinician') decoupled from the API
// vocabulary is a one-line change here.
function roleToMode(role) {
  if (role === 'doctor' || role === 'professional') return 'professional';
  return 'patient';
}

// Backwards compatibility: if the back-end is an older notebook that still
// returns { answer, sources: ["NHS — Asthma"] }, normalise into the new
// shape so the UI doesn't have to care.
const SOURCE_BASE_URLS = {
  NHS: 'https://www.nhs.uk/conditions/',
  NICE: 'https://www.nice.org.uk/guidance',
  PubMed: 'https://pubmed.ncbi.nlm.nih.gov/',
  MedQuAD: '#',
};

function legacySourceToCitation(s) {
  const parts = s.split(/\s+[—-]\s+/);
  const source = parts[0] || 'Source';
  const title = parts[1] || s;
  const base = SOURCE_BASE_URLS[source] || '#';
  if (base === '#' || source === 'NICE') {
    return { title, source, url: base };
  }
  const slug = title
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '');
  return { title, source, url: `${base}${slug}/` };
}

function normaliseResponse(data) {
  if (data && typeof data.answer_text === 'string' && Array.isArray(data.citations)) {
    return data;
  }
  const answer_text = data.answer || '';
  const sources = Array.isArray(data.sources) ? data.sources : [];
  return {
    query: data.query || '',
    mode: data.mode || 'patient',
    answer_text,
    citations: sources.map(legacySourceToCitation),
    emergency_flag: !!data.emergency_flag,
    emergency_category: data.emergency_category || null,
    safety_note: data.safety_note || '',
    refusal: !!data.refusal,
  };
}

export const fetchEduCareQuery = async (queryText, role, topK = 3) => {
  const mode = roleToMode(role);

  const resp = await fetch(`${API_BASE_URL}/answer`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'ngrok-skip-browser-warning': 'true',
    },
    body: JSON.stringify({ query: queryText, mode, top_k: topK }),
  });

  if (!resp.ok) {
    const detail = await resp.text().catch(() => '');
    throw new Error(`API ${resp.status}: ${detail || resp.statusText}`);
  }

  const data = await resp.json();
  return normaliseResponse(data);
};

export const checkEduCareHealth = async () => {
  const resp = await fetch(`${API_BASE_URL}/health`, {
    headers: { 'ngrok-skip-browser-warning': 'true' },
  });
  if (!resp.ok) throw new Error(`Health check failed: ${resp.status}`);
  return resp.json();
};

export { API_BASE_URL };
