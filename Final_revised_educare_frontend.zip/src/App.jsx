import React, { useEffect, useState } from 'react';
import './App.css';
import InputUI from './components/InputUI';
import DisplayOutput from './components/DisplayOutput';
import ApiStatusBadge from './components/ApiStatusBadge';
import { fetchEduCareQuery, checkEduCareHealth } from './api/apiClient';

export default function App() {
  const [userRole, setUserRole] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [history, setHistory] = useState([]);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [apiStatus, setApiStatus] = useState({ state: 'unknown', detail: '' });

  // Probe the back-end as soon as the user logs in, so they get instant
  // feedback if the API URL in .env is wrong / the ngrok tunnel has died /
  // the notebook isn't running yet.
  useEffect(() => {
    if (!isLoggedIn) return;
    let cancelled = false;
    setApiStatus({ state: 'checking', detail: '' });
    checkEduCareHealth()
      .then((info) => {
        if (cancelled) return;
        setApiStatus({
          state: 'connected',
          detail: `${info.vectors ?? '?'} vectors · ${info.documents ?? '?'} documents`,
        });
      })
      .catch((err) => {
        if (cancelled) return;
        setApiStatus({ state: 'disconnected', detail: err.message });
      });
    return () => {
      cancelled = true;
    };
  }, [isLoggedIn]);

  const handleGuestLogin = (role) => {
    setUserRole(role);
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setData(null);
    setError(null);
    setHistory([]);
  };

  const handleQuerySubmit = async (query, role) => {
    setLoading(true);
    setError(null);

    if (role === 'doctor') {
      setHistory((prev) =>
        [query.length > 30 ? `${query.slice(0, 30)}…` : query, ...prev].slice(0, 5),
      );
    }

    try {
      const result = await fetchEduCareQuery(query, role);
      setData(result);
    } catch (err) {
      console.error('EduCare API call failed:', err);
      setError(err.message || 'Could not reach the EduCare AI service.');
      setData(null);
    } finally {
      setLoading(false);
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="login-page">
        <div className="login-card">
          <div className="brand-logo-container">
            <div className="medical-logo">
              <div className="medical-cross"></div>
            </div>
            <h1>EduCareAI</h1>
            <p>AI-Powered Health Assistant</p>
          </div>

          <div className="disabled-login">
            <input type="email" placeholder="Email Address" disabled />
            <button className="btn-disabled" disabled>
              Login with Email
            </button>
          </div>

          <div className="separator">
            <span>OR LOGIN AS GUEST</span>
          </div>

          <div className="guest-options">
            <button
              className="btn-guest doctor"
              onClick={() => handleGuestLogin('doctor')}
            >
              Login as Clinician
            </button>
            <button
              className="btn-guest patient"
              onClick={() => handleGuestLogin('patient')}
            >
              Login as Patient
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`app-wrapper ${userRole}-theme`}>
      {userRole === 'doctor' && (
        <aside className="sidebar">
          <div className="sidebar-header">
            <div className="medical-logo mini">
              <div className="medical-cross mini"></div>
            </div>
            <span>Clinical Pro</span>
          </div>

          <nav className="sidebar-nav">
            <small>MAIN MENU</small>
            <ul>
              <li className="active">Dashboard</li>
              <li>Patient Files</li>
            </ul>

            <small>RECENT QUERIES</small>
            <ul className="history-list">
              {history.length > 0 ? (
                history.map((item, i) => (
                  <li key={i} className="history-item" title={item}>
                    {item}
                  </li>
                ))
              ) : (
                <li className="history-empty">No recent history</li>
              )}
            </ul>
          </nav>

          <button className="logout-btn" onClick={handleLogout}>
            Sign Out
          </button>
        </aside>
      )}

      <main className="main-content">
        <header className="top-bar">
          <h2>{userRole === 'doctor' ? 'Clinical Analysis' : 'Patient Portal'}</h2>
          <div className="top-bar-right">
            <ApiStatusBadge status={apiStatus} />
            {userRole === 'patient' && (
              <button className="logout-link" onClick={handleLogout}>
                Logout
              </button>
            )}
          </div>
        </header>

        <div className="content-area">
          <InputUI
            onSubmit={handleQuerySubmit}
            isLoading={loading}
            userRole={userRole}
          />

          {error && (
            <div className="error-banner">
              <strong>Service unavailable:</strong> {error}
              <div className="error-hint">
                Check that Notebook A is running and that{' '}
                <code>VITE_API_BASE_URL</code> in <code>.env</code> matches the
                ngrok URL the notebook printed.
              </div>
            </div>
          )}

          {data && <DisplayOutput result={data} />}
        </div>
      </main>
    </div>
  );
}
