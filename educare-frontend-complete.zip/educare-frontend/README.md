# EduCare AI — Front-End

Vite + React 19 single-page app that talks to the FastAPI service exposed
by `EduCare_MVP_Revised.ipynb` (the back-end notebook).

## Architecture

```
educare-frontend/
├── .env.example              ← copy to .env, set VITE_API_BASE_URL
├── index.html                ← Vite entry
├── package.json
├── vite.config.js
├── eslint.config.js
└── src/
    ├── main.jsx              ← React entry point
    ├── App.jsx               ← Top-level state + routing (login / portal)
    ├── App.css               ← Component styles
    ├── index.css             ← Global resets only
    ├── api/
    │   └── apiClient.js      ← fetch wrapper around the FastAPI endpoints
    └── components/
        ├── ApiStatusBadge.jsx   ← Live API health pill in the top bar
        ├── Disclaimer.jsx       ← AI-generated content disclaimer
        ├── DisplayOutput.jsx    ← Renders answer + citations + safety banner
        ├── InputUI.jsx          ← Query textarea + example chips + submit
        └── SafetyBanner.jsx     ← Soft warning + urgent variant
```

## How the wiring works

| User action | What happens |
|---|---|
| Lands on `/` | `App` renders the login card; no API call yet. |
| Clicks **Login as Patient** or **Login as Clinician** | `App` flips `isLoggedIn` and stores the role (`'patient'` or `'doctor'`). |
| Login completes | `useEffect` fires `checkEduCareHealth()` against `${API_BASE_URL}/health`. The result drives the `ApiStatusBadge` (green / yellow / red dot in the top bar). |
| Types a question + hits submit | `App.handleQuerySubmit` → `fetchEduCareQuery(query, role)` → `POST ${API_BASE_URL}/answer` with `{ query, mode, top_k: 3 }` where `mode` is `'professional'` if role is `'doctor'`, else `'patient'`. |
| API responds | `DisplayOutput` shows the answer, the citation list (each clickable to its NHS / NICE source URL), and an urgent safety banner if `emergency_flag` is true (with category-specific copy). |
| API errors | `App` catches and shows an `error-banner` with a hint pointing back to `.env` configuration. |

## Setup

```bash
# 1. Install dependencies
npm install

# 2. Configure the API URL
cp .env.example .env
#    edit .env: set VITE_API_BASE_URL to the URL Notebook A prints out
#    (the line beginning "Public URL: https://...ngrok-free.app")

# 3. Run the dev server
npm run dev
```

The app will be at <http://localhost:5173>.

## Running end-to-end with Notebook A

1. Open `EduCare_MVP_Revised.ipynb` in Google Colab and run all cells
   top-to-bottom.
2. The ngrok cell prints something like:
   ```
   Public URL: https://abcd-12-34-56-78.ngrok-free.app
   ```
   Copy that URL.
3. In `educare-frontend/.env`:
   ```
   VITE_API_BASE_URL=https://abcd-12-34-56-78.ngrok-free.app
   ```
4. `npm run dev`, open <http://localhost:5173>, log in, ask a question.

The API status badge at the top should turn green within a few seconds of
login. If it stays red, check `.env` and that Notebook A's FastAPI cell is
still running.

## Smoke tests (with the 30-document corpus)

| Login as | Query | Expected |
|---|---|---|
| Patient | What are the symptoms of asthma? | Plain-English answer · NHS asthma citation · soft yellow banner only |
| Patient | I'm having an asthma attack and can't breathe | **Red urgent banner** above the answer (category: respiratory) · 999 advice prepended |
| Patient | How many mg of metformin should I take? | Refusal text directing to GP / pharmacist / NHS 111 |
| Patient | What are the signs of depression? | Plain-English answer · NHS Depression citation |
| Clinician | How is hypertension diagnosed? | Guideline-style answer mentioning 140/90, ABPM thresholds · NICE Hypertension citation |
| Clinician | First-line drug for type 2 diabetes? | Mentions metformin · NICE Type 2 Diabetes citation |
| Clinician | What are the high-risk criteria for suspected sepsis? | Mentions lactate, vital-sign thresholds · NICE Sepsis citation |

## Mode mapping

The login screen uses `'doctor'` / `'patient'` because that's what the
clinical UI calls them. The API uses `'professional'` / `'patient'` because
that's the proposal vocabulary. Translation lives in
`src/api/apiClient.js` (`roleToMode`) so the UI copy and API contract can
evolve independently.

## CORS

The FastAPI service in Notebook A enables CORS with `allow_origins=["*"]`
by default. This is appropriate for a Colab + ngrok academic MVP where the
public URL changes every session. **For Sprint 3**, restrict
`allow_origins` to the deployed front-end origin.

## Linting

```bash
npm run lint
```

The repo's existing `eslint.config.js` is used unchanged.

## Build for production

```bash
npm run build
npm run preview   # serve the production build locally
```

Build output goes to `dist/`. To deploy, point any static host at it (Vercel,
Netlify, GitHub Pages, etc.) and set `VITE_API_BASE_URL` at build time.
